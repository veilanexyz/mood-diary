function saveMoodPeriod(period, context) {
    addAction({
        type: "save_mood_period",
        period: period
    }, context);
}

function saveFeelingDescription(description, context) {
    addAction({
        type: "save_feeling_description",
        description: description
    }, context);
}

function saveInfluenceFactors(factors, context) {
    addAction({
        type: "save_influence_factors",
        factors: factors
    }, context);
}